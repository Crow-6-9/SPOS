public class MacroDefinitionTable {

	String def;
}
