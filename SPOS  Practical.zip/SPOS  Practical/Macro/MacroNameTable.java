public class MacroNameTable {

	String name;
	String address;
	String arg[] = new String[5];
	
	public MacroNameTable() {
		
		name = "\0";
		address = "\0";
	}
}